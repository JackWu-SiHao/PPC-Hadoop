$ bin/hadoop pipes -conf wordcount.xml -input YOUR_INPUT_PATH
	-output YOUR_OUTPUT_PATH
