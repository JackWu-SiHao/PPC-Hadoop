void map( HadoopPipes::MapContext& context ) {
	// insert your code here
}
